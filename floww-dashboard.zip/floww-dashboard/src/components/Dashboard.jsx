// src/components/Dashboard.jsx
import React from "react";

function Dashboard({ user, tasks, stats }) {
  return (
    <div style={{ maxWidth: "700px", margin: "40px auto", fontFamily: "Arial, sans-serif" }}>
      <header style={{ display: "flex", alignItems: "center", marginBottom: "30px" }}>
        <img
          src={user.profilePic}
          alt={user.name}
          style={{ width: "100px", borderRadius: "50%", marginRight: "20px" }}
        />
        <div>
          <h1>Welcome back, {user.name}!</h1>
          <p>{user.email}</p>
          <p>{user.location}</p>
        </div>
      </header>

      <section style={{ marginBottom: "30px" }}>
        <h2>Your Stats</h2>
        <ul>
          <li>Projects Completed: {stats.projectsCompleted}</li>
          <li>Hours Worked: {stats.hoursWorked}</li>
        </ul>
      </section>

      <section>
        <h2>Today's Tasks</h2>
        <ul>
          {tasks.length > 0 ? (
            tasks.map((task, index) => <li key={index}>{task}</li>)
          ) : (
            <p>No tasks for today!</p>
          )}
        </ul>
      </section>
    </div>
  );
}

export default Dashboard;
