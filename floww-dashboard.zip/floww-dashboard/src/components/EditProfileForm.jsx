import React, { useState } from "react";

export default function EditProfileForm({ user, updateUser, closeForm }) {
  const [formData, setFormData] = useState({
    name: user.name,
    email: user.email,
    profilePicture: user.profilePicture,
  });

  const handleChange = (e) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    updateUser(formData);
    closeForm();
  };

  return (
    <form onSubmit={handleSubmit} className="edit-profile-form">
      <label>
        Name:
        <input
          name="name"
          value={formData.name}
          onChange={handleChange}
          required
        />
      </label>
      <label>
        Email:
        <input
          name="email"
          value={formData.email}
          onChange={handleChange}
          required
        />
      </label>
      <label>
        Profile Picture URL:
        <input
          name="profilePicture"
          value={formData.profilePicture}
          onChange={handleChange}
          required
        />
      </label>
      <button type="submit">Save</button>{" "}
      <button type="button" onClick={closeForm}>
        Cancel
      </button>
    </form>
  );
}
