import React from "react";
import { Routes, Route } from "react-router-dom";
import LoginPage from "./components/LoginPage";
import SignUpPage from "./components/SignUpPage";
import Dashboard from "./components/Dashboard";

const demoUser = {
  name: "Elon Musk",
  email: "elon.musk@example.com",
  location: "San Francisco, CA",
  profilePic: "/elon.jpg", // keep the elon.jpg image in public folder
};

const demoTasks = [
  "Complete project proposal",
  "Review design mockups",
  "Prepare presentation",
  "Update documentation",
];

const demoStats = {
  projectsCompleted: 12,
  hoursWorked: 340,
};

function App() {
  return (
    <Routes>
      <Route path="/" element={<LoginPage />} />
      <Route path="/signup" element={<SignUpPage />} />
      <Route
        path="/dashboard"
        element={<Dashboard user={demoUser} tasks={demoTasks} stats={demoStats} />}
      />
    </Routes>
  );
}

export default App;
