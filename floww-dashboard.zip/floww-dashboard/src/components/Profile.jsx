import React, { useState } from "react";
import EditProfileForm from "./EditProfileForm";

export default function Profile({ user, updateUser }) {
  const [editing, setEditing] = useState(false);

  return (
    <div className="profile-section card">
      <h2>Profile Information</h2>
      {!editing ? (
        <>
          <img
            src={user.profilePicture}
            alt="Profile"
            className="profile-pic"
          />
          <p><strong>Name:</strong> {user.name}</p>
          <p><strong>Email:</strong> {user.email}</p>
          <button onClick={() => setEditing(true)}>Edit Profile</button>
        </>
      ) : (
        <EditProfileForm
          user={user}
          updateUser={updateUser}
          closeForm={() => setEditing(false)}
        />
      )}
    </div>
  );
}
