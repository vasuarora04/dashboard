import React from "react";

export default function Statistics({ tasks }) {
  const completedCount = tasks.filter((t) => t.completed).length;
  const pendingCount = tasks.length - completedCount;

  return (
    <div className="statistics-section card">
      <h2>Statistics</h2>
      <p>Completed Tasks: {completedCount}</p>
      <p>Pending Tasks: {pendingCount}</p>
    </div>
  );
}
