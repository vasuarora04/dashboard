# Floww Dashboard - Frontend Intern Assignment

## 🔧 Tech Stack
- React.js
- HTML, CSS, JavaScript
- Mock API using local JSON

## 🧩 Components
- **Profile**: View and edit user info
- **Tasks**: List of tasks with checkbox
- **Statistics**: Shows completed & pending tasks

## 📁 Folder Structure
- `components/` - UI components
- `data/` - mock API JSON
- `App.js` - main logic
- `App.css` - styling

## 🚀 How to Run
1. Clone the repo or unzip
2. Run: `npm install`
3. Start server: `npm start`

## 📄 Notes
- Fully responsive design
- Form validation in EditProfileForm